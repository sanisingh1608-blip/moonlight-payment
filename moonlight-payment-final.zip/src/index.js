import { MENU } from "./menu.js";

const SHOP_LAT=22.3454, SHOP_LNG=82.6967, MAX_KM=10;
const cors={"Access-Control-Allow-Origin":"https://moonlightbiryani.in","Access-Control-Allow-Methods":"GET,POST,OPTIONS","Access-Control-Allow-Headers":"Content-Type","Content-Type":"application/json;charset=UTF-8"};
const out=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:cors});
const text=(x,n=500)=>String(x??"").trim().slice(0,n);
const phoneOk=x=>/^[6-9]\d{9}$/.test(String(x??"").replace(/\D/g,""));
function dist(lat,lng){const p=Math.PI/180,a=.5-Math.cos((lat-SHOP_LAT)*p)/2+Math.cos(SHOP_LAT*p)*Math.cos(lat*p)*(1-Math.cos((lng-SHOP_LNG)*p))/2;return 12742*Math.asin(Math.sqrt(a));}
function delivery(k){return k<=5?50:k<=10?80:null;}
function calc(items,k){
 if(!Array.isArray(items)||!items.length)throw Error("Cart is empty.");
 const map=new Map(MENU.map(x=>[x.id,x])), rows=[]; let food=0;
 for(const r of items){const i=map.get(String(r?.id)),q=Number(r?.qty);if(!i||!Number.isInteger(q)||q<1||q>20)throw Error("Invalid cart item.");const line=i.price*q;food+=line;rows.push({id:i.id,name:i.name,price:i.price,qty:q,lineTotal:line});}
 const d=delivery(k);if(d===null)throw Error("Delivery is available only up to 10 KM.");
 return {items:rows,foodTotal:food,delivery:d,total:food+d,distanceKm:+k.toFixed(2)};
}
async function rp(path,env,opts={}){
 const auth=btoa(`${env.RAZORPAY_KEY_ID}:${env.RAZORPAY_KEY_SECRET}`);
 const r=await fetch("https://api.razorpay.com/v1"+path,{...opts,headers:{Authorization:`Basic ${auth}`,"Content-Type":"application/json",...(opts.headers||{})}});
 const d=await r.json();if(!r.ok)throw Error(d?.error?.description||"Razorpay API error");return d;
}
async function hmac(secret,msg){const k=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return [...new Uint8Array(await crypto.subtle.sign("HMAC",k,new TextEncoder().encode(msg)))].map(x=>x.toString(16).padStart(2,"0")).join("");}
function equal(a,b){if(typeof a!=="string"||typeof b!=="string"||a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0;}

export default {async fetch(req,env){
 if(req.method==="OPTIONS")return new Response(null,{status:204,headers:cors});
 const u=new URL(req.url);
 if(!u.pathname.startsWith("/api/"))return env.ASSETS.fetch(req);
 try{
  if(req.method==="GET"&&u.pathname==="/api/health")return out({ok:true});
  if(req.method==="GET"&&u.pathname==="/api/config")return out({razorpayKeyId:env.RAZORPAY_KEY_ID,menu:MENU});
  if(req.method==="POST"&&u.pathname==="/api/calculate"){
   const b=await req.json(),lat=Number(b.lat),lng=Number(b.lng);if(!Number.isFinite(lat)||!Number.isFinite(lng))return out({error:"Valid location required."},400);
   const k=dist(lat,lng),d=delivery(k);if(d===null)return out({error:"Delivery available only up to 10 KM.",distanceKm:+k.toFixed(2)},400);
   return out({ok:true,distanceKm:+k.toFixed(2),deliveryCharge:d});
  }
  if(req.method==="POST"&&u.pathname==="/api/create-order"){
   const b=await req.json(),name=text(b.customerName,80),ph=String(b.phone??"").replace(/\D/g,""),addr=text(b.address,500),lat=Number(b.lat),lng=Number(b.lng);
   if(!name||!phoneOk(ph)||!addr||!Number.isFinite(lat)||!Number.isFinite(lng))return out({error:"Name, valid mobile, address and location are required."},400);
   const k=dist(lat,lng),order=calc(b.items,k);
   const r=await rp("/orders",env,{method:"POST",body:JSON.stringify({amount:order.total*100,currency:"INR",receipt:`MBNS_${Date.now()}`,notes:{customer:name,phone:ph,distance:String(order.distanceKm)}})});
   return out({ok:true,orderId:r.id,amount:r.amount,currency:r.currency,order});
  }
  if(req.method==="POST"&&u.pathname==="/api/verify-payment"){
   const b=await req.json(),oid=text(b.razorpay_order_id,100),pid=text(b.razorpay_payment_id,100),sig=text(b.razorpay_signature,200);
   if(!oid||!pid||!sig)return out({verified:false,orderConfirmed:false,error:"Incomplete payment data."},400);
   const expected=await hmac(env.RAZORPAY_KEY_SECRET,`${oid}|${pid}`);if(!equal(expected,sig))return out({verified:false,orderConfirmed:false,error:"Invalid payment signature."},400);
   const p=await rp(`/payments/${encodeURIComponent(pid)}`,env),o=await rp(`/orders/${encodeURIComponent(oid)}`,env);
   if(p.order_id!==oid||p.status!=="captured")return out({verified:false,orderConfirmed:false,error:"Payment is not captured."},400);
   if(Number(p.amount)!==Number(o.amount))return out({verified:false,orderConfirmed:false,error:"Payment amount mismatch."},400);
   return out({verified:true,orderConfirmed:true,paymentId:pid,orderId:oid,amount:Number(p.amount)});
  }
  return out({error:"Not found"},404);
 }catch(e){return out({error:e?.message||"Server error"},500);}
}};
